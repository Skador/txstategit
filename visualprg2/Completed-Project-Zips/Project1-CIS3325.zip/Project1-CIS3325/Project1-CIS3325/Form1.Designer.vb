﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.MonthlySalaryLbl = New System.Windows.Forms.Label()
        Me.FirstNameTxt = New System.Windows.Forms.TextBox()
        Me.LastNameTxt = New System.Windows.Forms.TextBox()
        Me.NoOfWeekTxt = New System.Windows.Forms.TextBox()
        Me.WeeklyHoursTxt = New System.Windows.Forms.TextBox()
        Me.SalaryPerHourTxt = New System.Windows.Forms.TextBox()
        Me.MonthsOfPaymentTxt = New System.Windows.Forms.TextBox()
        Me.SaveBtn = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.YearlySalaryLbl = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(75, 40)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "First Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(75, 69)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Last Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(64, 98)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "No of Weeks"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(59, 127)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Weekly Hours"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(52, 157)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Salary per Hour"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(55, 186)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Monthly Salary"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(34, 215)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(98, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Months of Payment"
        '
        'MonthlySalaryLbl
        '
        Me.MonthlySalaryLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.MonthlySalaryLbl.Location = New System.Drawing.Point(152, 185)
        Me.MonthlySalaryLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.MonthlySalaryLbl.Name = "MonthlySalaryLbl"
        Me.MonthlySalaryLbl.Size = New System.Drawing.Size(101, 17)
        Me.MonthlySalaryLbl.TabIndex = 7
        '
        'FirstNameTxt
        '
        Me.FirstNameTxt.Location = New System.Drawing.Point(152, 38)
        Me.FirstNameTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FirstNameTxt.Name = "FirstNameTxt"
        Me.FirstNameTxt.Size = New System.Drawing.Size(103, 20)
        Me.FirstNameTxt.TabIndex = 8
        '
        'LastNameTxt
        '
        Me.LastNameTxt.Location = New System.Drawing.Point(152, 67)
        Me.LastNameTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.LastNameTxt.Name = "LastNameTxt"
        Me.LastNameTxt.Size = New System.Drawing.Size(103, 20)
        Me.LastNameTxt.TabIndex = 9
        '
        'NoOfWeekTxt
        '
        Me.NoOfWeekTxt.Location = New System.Drawing.Point(152, 96)
        Me.NoOfWeekTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.NoOfWeekTxt.Name = "NoOfWeekTxt"
        Me.NoOfWeekTxt.Size = New System.Drawing.Size(103, 20)
        Me.NoOfWeekTxt.TabIndex = 10
        '
        'WeeklyHoursTxt
        '
        Me.WeeklyHoursTxt.Location = New System.Drawing.Point(152, 126)
        Me.WeeklyHoursTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.WeeklyHoursTxt.Name = "WeeklyHoursTxt"
        Me.WeeklyHoursTxt.Size = New System.Drawing.Size(103, 20)
        Me.WeeklyHoursTxt.TabIndex = 11
        '
        'SalaryPerHourTxt
        '
        Me.SalaryPerHourTxt.Location = New System.Drawing.Point(152, 155)
        Me.SalaryPerHourTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.SalaryPerHourTxt.Name = "SalaryPerHourTxt"
        Me.SalaryPerHourTxt.Size = New System.Drawing.Size(103, 20)
        Me.SalaryPerHourTxt.TabIndex = 12
        '
        'MonthsOfPaymentTxt
        '
        Me.MonthsOfPaymentTxt.Location = New System.Drawing.Point(152, 213)
        Me.MonthsOfPaymentTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.MonthsOfPaymentTxt.Name = "MonthsOfPaymentTxt"
        Me.MonthsOfPaymentTxt.Size = New System.Drawing.Size(103, 20)
        Me.MonthsOfPaymentTxt.TabIndex = 13
        '
        'SaveBtn
        '
        Me.SaveBtn.Location = New System.Drawing.Point(295, 92)
        Me.SaveBtn.Margin = New System.Windows.Forms.Padding(2)
        Me.SaveBtn.Name = "SaveBtn"
        Me.SaveBtn.Size = New System.Drawing.Size(62, 21)
        Me.SaveBtn.TabIndex = 14
        Me.SaveBtn.Text = "Save"
        Me.SaveBtn.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(290, 125)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(68, 13)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Yearly Salary"
        '
        'YearlySalaryLbl
        '
        Me.YearlySalaryLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.YearlySalaryLbl.Location = New System.Drawing.Point(275, 150)
        Me.YearlySalaryLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.YearlySalaryLbl.Name = "YearlySalaryLbl"
        Me.YearlySalaryLbl.Size = New System.Drawing.Size(101, 17)
        Me.YearlySalaryLbl.TabIndex = 16
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(390, 280)
        Me.Controls.Add(Me.YearlySalaryLbl)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.SaveBtn)
        Me.Controls.Add(Me.MonthsOfPaymentTxt)
        Me.Controls.Add(Me.SalaryPerHourTxt)
        Me.Controls.Add(Me.WeeklyHoursTxt)
        Me.Controls.Add(Me.NoOfWeekTxt)
        Me.Controls.Add(Me.LastNameTxt)
        Me.Controls.Add(Me.FirstNameTxt)
        Me.Controls.Add(Me.MonthlySalaryLbl)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents MonthlySalaryLbl As System.Windows.Forms.Label
    Friend WithEvents FirstNameTxt As System.Windows.Forms.TextBox
    Friend WithEvents LastNameTxt As System.Windows.Forms.TextBox
    Friend WithEvents NoOfWeekTxt As System.Windows.Forms.TextBox
    Friend WithEvents WeeklyHoursTxt As System.Windows.Forms.TextBox
    Friend WithEvents SalaryPerHourTxt As System.Windows.Forms.TextBox
    Friend WithEvents MonthsOfPaymentTxt As System.Windows.Forms.TextBox
    Friend WithEvents SaveBtn As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents YearlySalaryLbl As System.Windows.Forms.Label

End Class
