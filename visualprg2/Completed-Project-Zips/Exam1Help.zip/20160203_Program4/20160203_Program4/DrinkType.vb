﻿Public Class DrinkType
    Public Name As String
    Public Price As Double

    Public Overrides Function ToString() As String
        Return Name
    End Function

End Class
