﻿
Partial Class Error
    Inherits System.Web.UI.Page

End Class
