/**
 * Created by Michelle Leipnik and Cody Kern on 3/19/2017.
 */
public interface Driver {
  String driveCar(String car);
}
